package com.example.qr_school_attendance

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
