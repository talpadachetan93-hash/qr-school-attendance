import 'dart:convert';
import 'dart:io';
import 'package:csv/csv.dart';
import 'package:flutter/material.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import 'package:path_provider/path_provider.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:share_plus/share_plus.dart';

void main() => runApp(const SchoolAttendanceApp());

class Student {
  final String id,name,roll,className;
  Student({required this.id,required this.name,required this.roll,required this.className});
  Map<String,dynamic> toJson()=>{'id':id,'name':name,'roll':roll,'className':className};
  factory Student.fromJson(Map<String,dynamic> j)=>Student(id:j['id'],name:j['name'],roll:j['roll'],className:j['className']);
}

class Store {
  static const sk='students', ak='attendance', ck='classes';
  static Future<List<Student>> students() async {
    final p=await SharedPreferences.getInstance();
    return (p.getStringList(sk)??[]).map((x)=>Student.fromJson(jsonDecode(x))).toList();
  }
  static Future<void> saveStudent(Student s) async {
    final p=await SharedPreferences.getInstance(); final a=p.getStringList(sk)??[];
    a.add(jsonEncode(s.toJson())); await p.setStringList(sk,a);
  }
  static Future<List<String>> classes() async {
    final p=await SharedPreferences.getInstance();
    return p.getStringList(ck)??['5-A','6-A','7-A'];
  }
  static Future<void> saveClass(String c) async {
    final p=await SharedPreferences.getInstance(); final a=await classes();
    if(!a.contains(c)) {a.add(c); await p.setStringList(ck,a);}
  }
  static Future<List<String>> attendance() async {
    final p=await SharedPreferences.getInstance(); return p.getStringList(ak)??[];
  }
  static Future<bool> mark(String id) async {
    final p=await SharedPreferences.getInstance(); final a=await attendance();
    final d=DateTime.now(); final key='${d.year}-${d.month}-${d.day}|$id';
    if(a.contains(key)) return false; a.add(key); await p.setStringList(ak,a); return true;
  }
}

class SchoolAttendanceApp extends StatelessWidget {
  const SchoolAttendanceApp({super.key});
  @override Widget build(BuildContext c)=>MaterialApp(
    debugShowCheckedModeBanner:false,title:'School QR Attendance',
    theme:ThemeData(colorScheme:ColorScheme.fromSeed(seedColor:Colors.indigo),useMaterial3:true),
    home:const LoginPage());
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});
  @override State<LoginPage> createState()=>_LoginPageState();
}
class _LoginPageState extends State<LoginPage>{
  final user=TextEditingController(), pass=TextEditingController();
  String error='';
  void login(){
    if((user.text=='admin'||user.text=='teacher') && pass.text=='1234')
      Navigator.pushReplacement(context,MaterialPageRoute(builder:(_)=>Home(role:user.text)));
    else setState(()=>error='Demo login: teacher / 1234 or admin / 1234');
  }
  @override Widget build(BuildContext c)=>Scaffold(body:Center(child:SingleChildScrollView(
    padding:const EdgeInsets.all(28),child:Column(children:[
      const Icon(Icons.school,size:72),const SizedBox(height:12),
      Text('School QR Attendance',style:Theme.of(c).textTheme.headlineSmall),
      const SizedBox(height:30),
      TextField(controller:user,decoration:const InputDecoration(labelText:'Username',prefixIcon:Icon(Icons.person))),
      TextField(controller:pass,obscureText:true,decoration:const InputDecoration(labelText:'Password',prefixIcon:Icon(Icons.lock))),
      const SizedBox(height:18),FilledButton(onPressed:login,child:const Text('Login')),
      if(error.isNotEmpty) Padding(padding:const EdgeInsets.all(12),child:Text(error))
    ]))));
}

class Home extends StatefulWidget { final String role; const Home({super.key,required this.role});
@override State<Home> createState()=>_HomeState();}
class _HomeState extends State<Home>{
 int tab=0;
 @override Widget build(BuildContext c){
  final pages=[Dashboard(role:widget.role),Students(),AttendanceReport(),if(widget.role=='admin') Classes()];
  return Scaffold(appBar:AppBar(title:Text('School Attendance • ${widget.role}')),
   body:pages[tab],
   floatingActionButton:FloatingActionButton.extended(onPressed:()async{
    await Navigator.push(c,MaterialPageRoute(builder:(_)=>const Scanner()));
    setState((){});
   },icon:const Icon(Icons.qr_code_scanner),label:const Text('Scan')),
   bottomNavigationBar:NavigationBar(selectedIndex:tab,onDestinationSelected:(i)=>setState(()=>tab=i),
    destinations:[
      const NavigationDestination(icon:Icon(Icons.dashboard),label:'Dashboard'),
      const NavigationDestination(icon:Icon(Icons.people),label:'Students'),
      const NavigationDestination(icon:Icon(Icons.fact_check),label:'Reports'),
      if(widget.role=='admin') const NavigationDestination(icon:Icon(Icons.class_),label:'Classes')
    ]));
 }
}

class Dashboard extends StatelessWidget{
 final String role; const Dashboard({super.key,required this.role});
 @override Widget build(BuildContext c)=>FutureBuilder(future:Future.wait([Store.students(),Store.attendance()]),builder:(_,s){
  if(!s.hasData)return const Center(child:CircularProgressIndicator());
  final st=s.data![0] as List<Student>, at=s.data![1] as List<String>,d=DateTime.now(),p='${d.year}-${d.month}-${d.day}|';
  final present=at.where((x)=>x.startsWith(p)).length;
  return ListView(padding:const EdgeInsets.all(16),children:[
   Text('Today',style:Theme.of(c).textTheme.headlineMedium),const SizedBox(height:16),
   Row(children:[Expanded(child:Card(child:ListTile(leading:const Icon(Icons.people),title:Text('${st.length}'),subtitle:const Text('Students')))),
   const SizedBox(width:10),Expanded(child:Card(child:ListTile(leading:const Icon(Icons.check_circle),title:Text('$present'),subtitle:const Text('Present'))))]),
   Card(child:ListTile(leading:const Icon(Icons.person_off),title:Text('${(st.length-present).clamp(0,st.length)}'),subtitle:const Text('Absent'))),
   const SizedBox(height:20),Text('Logged in as $role'),const SizedBox(height:8),
   const ListTile(leading:Icon(Icons.qr_code),title:Text('QR-based attendance'),subtitle:Text('One valid attendance per student per day.')),
   const ListTile(leading:Icon(Icons.cloud),title:Text('Production upgrade'),subtitle:Text('Connect Firebase for multi-device school data.'))
  ]);
 });
}

class Students extends StatefulWidget{const Students({super.key});@override State<Students> createState()=>_StudentsState();}
class _StudentsState extends State<Students>{
 Future<void> add()async{
  final n=TextEditingController(),r=TextEditingController(),cl=TextEditingController();
  final ok=await showDialog<bool>(context:context,builder:(_)=>AlertDialog(title:const Text('Add Student'),content:Column(mainAxisSize:MainAxisSize.min,children:[
   TextField(controller:n,decoration:const InputDecoration(labelText:'Name')),TextField(controller:r,decoration:const InputDecoration(labelText:'Roll No.')),TextField(controller:cl,decoration:const InputDecoration(labelText:'Class / Division'))
  ]),actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('Cancel')),FilledButton(onPressed:()=>Navigator.pop(context,true),child:const Text('Save'))]));
  if(ok==true&&n.text.trim().isNotEmpty){await Store.saveStudent(Student(id:DateTime.now().microsecondsSinceEpoch.toString(),name:n.text.trim(),roll:r.text.trim(),className:cl.text.trim()));setState((){});}
 }
 @override Widget build(BuildContext c)=>Scaffold(body:FutureBuilder(future:Store.students(),builder:(_,s){
  if(!s.hasData)return const Center(child:CircularProgressIndicator()); final a=s.data as List<Student>;
  return ListView(children:[for(final x in a)ListTile(leading:CircleAvatar(child:Text(x.roll.isEmpty?'?':x.roll)),title:Text(x.name),subtitle:Text('Roll ${x.roll} • ${x.className}'),trailing:IconButton(icon:const Icon(Icons.qr_code),onPressed:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>QR(student:x)))))]);}),floatingActionButton:FloatingActionButton(onPressed:add,child:const Icon(Icons.add)));
 }
}

class QR extends StatelessWidget{final Student student;const QR({super.key,required this.student});
@override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Student QR')),body:Center(child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[
 Text(student.name,style:Theme.of(c).textTheme.headlineSmall),Text('Roll ${student.roll} • ${student.className}'),const SizedBox(height:25),
 QrImageView(data:'STUDENT:${student.id}',size:280),const SizedBox(height:15),const Text('Show this QR to the teacher')
])));}

class Scanner extends StatefulWidget{const Scanner({super.key});@override State<Scanner> createState()=>_ScannerState();}
class _ScannerState extends State<Scanner>{bool busy=false;
 Future<void> scan(String? code)async{
  if(busy||code==null||!code.startsWith('STUDENT:'))return;busy=true;
  final id=code.substring(8), list=await Store.students(), m=list.where((x)=>x.id==id).toList();
  if(!mounted)return;
  if(m.isEmpty){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Invalid student QR')));busy=false;return;}
  final s=m.first, ok=await Store.mark(s.id);
  await showDialog(context:context,builder:(_)=>AlertDialog(title:Text(ok?'Attendance Marked ✓':'Already Marked'),content:Text('${s.name}\nRoll ${s.roll}\nClass ${s.className}'),actions:[FilledButton(onPressed:()=>Navigator.pop(context),child:const Text('OK'))]));
  if(mounted)busy=false;
 }
 @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Scan Student QR')),body:MobileScanner(onDetect:(cap)=>scan(cap.barcodes.isEmpty ? null : cap.barcodes.first.rawValue)));
}

class AttendanceReport extends StatelessWidget{const AttendanceReport({super.key});
 Future<void> export(BuildContext c)async{
  final st=await Store.students(),at=await Store.attendance(); final rows=[['Date','Student','Roll','Class','Status']];
  for(final s in st){for(final a in at.where((x)=>x.endsWith('|${s.id}'))){rows.add([a.split('|').first,s.name,s.roll,s.className,'Present']);}}
  final csv=const ListToCsvConverter().convert(rows); final dir=await getTemporaryDirectory(); final f=File('${dir.path}/attendance.csv');await f.writeAsString(csv);
  await Share.shareXFiles([XFile(f.path)],text:'School attendance report');
 }
 @override Widget build(BuildContext c)=>FutureBuilder(future:Future.wait([Store.students(),Store.attendance()]),builder:(_,s){
  if(!s.hasData)return const Center(child:CircularProgressIndicator()); final st=s.data![0] as List<Student>,at=s.data![1] as List<String>;
  return Column(children:[ListTile(title:Text('Attendance records: ${at.length}'),trailing:FilledButton.icon(onPressed:()=>export(c),icon:const Icon(Icons.download),label:const Text('CSV'))),
   Expanded(child:ListView(children:[for(final a in at.reversed)ListTile(leading:const Icon(Icons.check_circle),title:Text(a.split('|').first),subtitle:Text(st.where((x)=>a.endsWith('|${x.id}')).map((x)=>'${x.name} • ${x.className}').isEmpty ? 'Unknown' : st.where((x)=>a.endsWith('|${x.id}')).map((x)=>'${x.name} • ${x.className}').first))]))]);
 });}

class Classes extends StatefulWidget{const Classes({super.key});@override State<Classes> createState()=>_ClassesState();}
class _ClassesState extends State<Classes>{Future<void> add()async{final x=TextEditingController();final ok=await showDialog<bool>(context:context,builder:(_)=>AlertDialog(title:const Text('Add Class'),content:TextField(controller:x,decoration:const InputDecoration(labelText:'e.g. 8-B')),actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('Cancel')),FilledButton(onPressed:()=>Navigator.pop(context,true),child:const Text('Save'))]));if(ok==true&&x.text.trim().isNotEmpty){await Store.saveClass(x.text.trim());setState((){});}}
@override Widget build(BuildContext c)=>Scaffold(body:FutureBuilder(future:Store.classes(),builder:(_,s)=>!s.hasData?const Center(child:CircularProgressIndicator()):ListView(children:[for(final x in s.data as List<String>)ListTile(leading:const Icon(Icons.class_),title:Text(x))])),floatingActionButton:FloatingActionButton(onPressed:add,child:const Icon(Icons.add)));}}
